export default class User{

    constructor(name,pass,email) {
        this.name = name
        this.pass = pass
        this.email=email
      }

      
}